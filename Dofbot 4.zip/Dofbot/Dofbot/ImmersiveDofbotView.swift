//
//  ImmersiveDofbotView.swift
//  Dofbot
//
//  Created by admin on 19/05/2026.
//


import SwiftUI
import RealityKit
import ARKit

struct ImmersiveDofbotView: View {
    
    @State private var handTracking = HandTrackingProvider()
    @State private var session = ARKitSession()
    
    var body: some View {
        RealityView { content in
            // 创建一个根实体
            let root = Entity()
            content.add(root)
            
            // 可以在这里添加你的机械臂3D模型（后续可扩展）
            
        } update: { content in
            // 每帧更新时可以在这里同步手部位置（可选）
        }
        .task {
            await startHandTracking()
        }
        .onDisappear {
            session.stop()
        }
    }
    
    private func startHandTracking() async {
        do {
            let authorization = await session.requestAuthorization(for: [.handTracking])
            guard authorization[.handTracking] == .allowed else {
                print("手部跟踪权限被拒绝")
                return
            }
            
            try await session.run([handTracking])
            
            // 监听手部更新（用于调试或手势可视化）
            for await update in handTracking.anchorUpdates {
                let handAnchor = update.anchor
                if handAnchor.isTracked {
                    print("检测到手部: \(handAnchor.chirality)")
                    // 这里可以后续添加手部骨骼可视化
                }
            }
        } catch {
            print("手部跟踪启动失败: \(error)")
        }
    }
}
