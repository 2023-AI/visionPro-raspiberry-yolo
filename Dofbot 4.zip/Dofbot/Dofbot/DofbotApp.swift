//
//  DofbotApp.swift
//  Dofbot
//
//  Created by admin on 19/05/2026.
//


import SwiftUI

@main
struct DofbotApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .windowStyle(.plain)           // 或 .volumetric 根据需要
        .defaultSize(width: 1000, height: 900)
        
        // 如果你想支持 Immersive Space（推荐手势控制）
        ImmersiveSpace(id: "dofbotImmersiveSpace") {
            ImmersiveDofbotView()
        }
    }
}