import SwiftUI
import Network
internal import Combine

// MARK: - DOFBOT TCP 客户端（【完全保留你原版代码，无任何修改/删减】）
class DofbotTCPClient: ObservableObject {
    // 你的树莓派真实IP
    private let raspberryPiIP = "192.168.35.32"
    private let port: UInt16 = 9500
    
    private var connection: NWConnection?
    private var reconnectTimer: Timer?
    
    @Published var isConnected = false
    @Published var connectionStatus = "未连接"
    @Published var lastResponse = ""
    @Published var errorLog = ""
    
    init() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleAppDidBecomeActive),
            name: UIApplication.didBecomeActiveNotification,
            object: nil
        )
    }
    
    @objc private func handleAppDidBecomeActive() {
        if !isConnected {
            connect()
        }
    }
    
    func connect() {
        disconnect()
        let host = NWEndpoint.Host(raspberryPiIP)
        guard let port = NWEndpoint.Port(rawValue: port) else {
            connectionStatus = "❌ 端口无效"
            errorLog = "端口号错误"
            return
        }
        connection = NWConnection(host: host, port: port, using: .tcp)
        connection?.stateUpdateHandler = { [weak self] state in
            DispatchQueue.main.async {
                guard let self = self else { return }
                switch state {
                case .ready:
                    self.isConnected = true
                    self.connectionStatus = "✅ 已连接到 DOFBOT"
                    self.errorLog = ""
                    self.reconnectTimer?.invalidate()
                    self.reconnectTimer = nil
                case .failed(let error):
                    self.isConnected = false
                    self.connectionStatus = "❌ 连接失败"
                    self.errorLog = "错误: \(error.localizedDescription)"
                    self.startAutoReconnect()
                case .cancelled:
                    self.isConnected = false
                    self.connectionStatus = "🔌 已断开"
                    self.errorLog = "连接被取消"
                case .waiting(let error):
                    self.isConnected = false
                    self.connectionStatus = "⏳ 等待连接..."
                    self.errorLog = "等待: \(error.localizedDescription)"
                default:
                    self.isConnected = false
                    self.connectionStatus = "⏳ 连接中..."
                }
            }
        }
        connection?.start(queue: .global())
    }
    
    private func startAutoReconnect() {
        reconnectTimer?.invalidate()
        reconnectTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true) { [weak self] _ in
            guard let self = self, !self.isConnected else {
                self?.reconnectTimer?.invalidate()
                return
            }
            self.connect()
        }
    }
    
    // 【原有发送指令函数 完全保留】
    func sendCommand(_ command: String) {
        guard let connection = connection, connection.state == .ready else {
            DispatchQueue.main.async {
                self.lastResponse = "❌ 未连接到机械臂"
            }
            return
        }
        let data = command.data(using: .utf8)!
        connection.send(content: data, completion: .contentProcessed({ [weak self] error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.lastResponse = "发送失败: \(error.localizedDescription)"
                    self?.errorLog = "发送错误: \(error.localizedDescription)"
                    self?.startAutoReconnect()
                    return
                }
                connection.receive(minimumIncompleteLength: 1, maximumLength: 1024) { data, _, _, error in
                    DispatchQueue.main.async {
                        if let data = data, !data.isEmpty {
                            let response = String(data: data, encoding: .utf8) ?? "无响应"
                            self?.lastResponse = response
                        } else if let error = error {
                            self?.lastResponse = "接收错误: \(error.localizedDescription)"
                            self?.errorLog = "接收错误: \(error.localizedDescription)"
                        }
                    }
                }
            }
        }))
    }
    
    // ==============================================
    // 【仅新增：滑块专用 绝对角度发送函数】无删减原有代码
    // ==============================================
    func sendSliderCommand(servoID: Int, angle: Int) {
        let command = "S\(servoID):\(angle)"
        sendCommand(command)
    }
    
    func disconnect() {
        reconnectTimer?.invalidate()
        reconnectTimer = nil
        connection?.cancel()
        connection = nil
        isConnected = false
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        disconnect()
    }
}

// MARK: - 舵机子控制页面（【仅修改这里：按钮 → 滑动摇杆】，其余全保留）
struct ServoControlView: View {
    @Environment(\.dismiss) var dismiss
    let client: DofbotTCPClient
    let servoName: String
    let servoID: Int
    let minAngle: Double
    let maxAngle: Double
    let midAngle: Double
    
    // 滑块状态
    @State private var currentSliderAngle: Double
    
    // 初始化：匹配机械臂安全角度
    init(client: DofbotTCPClient, servoID: Int, servoName: String) {
        self.client = client
        self.servoID = servoID
        self.servoName = servoName
        
        // 严格匹配Python端安全角度
        let limits = [
            1: (0, 180, 90),
            2: (30, 165, 90),
            3: (20, 150, 90),
            4: (0, 180, 90),
            5: (0, 270, 90),
            6: (30, 150, 90)
        ]
        let (min, max, mid) = limits[servoID]!
        self.minAngle = Double(min)
        self.maxAngle = Double(max)
        self.midAngle = Double(mid)
        self._currentSliderAngle = State(initialValue: self.midAngle)
    }
    
    var body: some View {
        VStack(spacing: 40) {
            Text("\(servoName) 滑动控制")
                .font(.largeTitle).bold()
            
            // 实时角度显示
            Text("当前角度：\(Int(currentSliderAngle))°")
                .font(.title)
                .foregroundColor(.blue)
            
            // 🔥 滑动摇杆（核心修改）
            Slider(value: $currentSliderAngle, in: minAngle...maxAngle, step: 1)
                .padding(.horizontal, 40)
                .onChange(of: currentSliderAngle) { newValue in
                    // 滑动实时发送绝对角度
                    client.sendSliderCommand(servoID: servoID, angle: Int(newValue))
                }
                .disabled(!client.isConnected)
                .controlSize(.large)
            
            // 一键复位中位
            Button("🔄 复位到中位") {
                currentSliderAngle = midAngle
                client.sendSliderCommand(servoID: servoID, angle: Int(midAngle))
            }
            .buttonStyle(ControlButtonStyle(color: .orange, width: 300, height: 80))
            .disabled(!client.isConnected)
            
            // 返回按钮
            Button("🔙 返回首页") {
                dismiss()
            }
            .buttonStyle(ControlButtonStyle(color: .gray, width: 300, height: 80))
            
            Spacer()
        }
        .padding(40)
        .frame(width: 1000, height: 950)
        .glassBackgroundEffect()
    }
}

// MARK: - 主页面（【100% 保留你原版代码，无任何修改】）
struct ContentView: View {
    @StateObject private var client = DofbotTCPClient()
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 25) {
                Text("🤖 DOFBOT 机械臂控制器")
                    .font(.largeTitle).fontWeight(.bold)
                
                HStack {
                    Circle().fill(client.isConnected ? Color.green : Color.red)
                        .frame(width: 16, height: 16)
                    Text(client.connectionStatus).font(.title3)
                }
                
                // 执行结果
                VStack(alignment: .leading, spacing: 8) {
                    Text("执行结果").font(.headline)
                    Text(client.lastResponse.isEmpty ? "等待指令..." : client.lastResponse)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(Color.gray.opacity(0.08))
                        .cornerRadius(12)
                }
                
                // 错误日志
                if !client.errorLog.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("错误日志").font(.headline).foregroundColor(.red)
                        Text(client.errorLog)
                            .foregroundColor(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                            .background(Color.red.opacity(0.08))
                            .cornerRadius(12)
                    }
                }
                
                // ====================== 原有控制按钮（完全保留） ======================
                VStack(spacing: 25) {
                    // 底座控制
                    HStack(spacing: 40) {
                        Button("⬅️ 底座左转") { client.sendCommand("BASE_LEFT") }
                            .buttonStyle(ControlButtonStyle(color: .blue))
                            .disabled(!client.isConnected)
                        Button("底座右转 ➡️") { client.sendCommand("BASE_RIGHT") }
                            .buttonStyle(ControlButtonStyle(color: .blue))
                            .disabled(!client.isConnected)
                    }
                    
                    // 独立舵机控制入口
                    Text("⚙️ 独立舵机精细控制")
                        .font(.title2).fontWeight(.semibold)
                        .foregroundColor(.orange)
                    
                    HStack(spacing: 20) {
                        NavigationLink("2号\n大臂") {
                            ServoControlView(client: client, servoID: 2, servoName: "2号大臂")
                        }
                        NavigationLink("3号\n小臂") {
                            ServoControlView(client: client, servoID: 3, servoName: "3号小臂")
                        }
                        NavigationLink("4号\n手腕") {
                            ServoControlView(client: client, servoID: 4, servoName: "4号手腕")
                        }
                    }
                    
                    HStack(spacing: 20) {
                        NavigationLink("5号\n旋爪") {
                            ServoControlView(client: client, servoID: 5, servoName: "5号旋爪")
                        }
                        NavigationLink("6号\n夹爪") {
                            ServoControlView(client: client, servoID: 6, servoName: "6号夹爪")
                        }
                    }
                    
                    // 原有夹爪控制
                    HStack(spacing: 40) {
                        Button("✋ 张开夹爪") { client.sendCommand("GRIPPER_OPEN") }
                            .buttonStyle(ControlButtonStyle(color: .orange))
                            .disabled(!client.isConnected)
                        Button("✊ 闭合夹爪") { client.sendCommand("GRIPPER_CLOSE") }
                            .buttonStyle(ControlButtonStyle(color: .orange))
                            .disabled(!client.isConnected)
                    }
                    
                    // 原有复位按钮
                    Button("🔄 机械臂复位") { client.sendCommand("RESET") }
                        .buttonStyle(ControlButtonStyle(color: .red, width: 400))
                        .disabled(!client.isConnected)
                }
                
                Spacer()
                
                // 原有连接按钮
                Button(client.isConnected ? "断开连接" : "连接机械臂") {
                    client.isConnected ? client.disconnect() : client.connect()
                }
                .buttonStyle(ControlButtonStyle(color: client.isConnected ? .gray : .green, width: 280, height: 70))
            }
            .padding(30)
            .frame(width: 1000, height: 950)
            .glassBackgroundEffect()
        }
    }
}

// MARK: - 按钮样式（【完全保留你原版代码】）
struct ControlButtonStyle: ButtonStyle {
    let color: Color
    var width: CGFloat = 180
    var height: CGFloat = 80
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.title2).fontWeight(.semibold)
            .frame(width: width, height: height)
            .background(color)
            .foregroundColor(.white)
            .cornerRadius(16)
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
    }
}

// MARK: - 预览
#Preview {
    ContentView()
}
