//
//  DofbotTests.swift
//  DofbotTests
//
//  Created by admin on 19/05/2026.
//

import Testing
@testable import Dofbot

struct DofbotTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
